#!/bin/sh

git submodule init
git submodule update
autoreconf -if
