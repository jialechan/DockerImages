05/30/03
Updated to use the common encoder_sample.c source in theora/examples.

05/23/03

Very simple port of the sample encoder for Windows, for testing.
Encoder options in the command line are not working, and the frame rate 
of video needs to be set in code (like in the simple sample encoder.)

This example will be updated to a true Win32 app sometime in the future,
hope it is useful for basic testing now.

mauricio@xiph.org